# Terms of Use — Georgia Bass Predictor

**Effective date:** [Insert date]  
**Operator:** [Insert legal business name]  
**Contact:** [Insert support email]

This draft must be reviewed and completed before launch.

## Informational fishing suggestions

Fishing recipes, depths, lure suggestions, and patterns are educational suggestions only. They are not guarantees, live fishing reports, or a substitute for local knowledge. Conditions change quickly. Users are responsible for checking weather, water conditions, boating safety, fishing regulations, licensing, and access restrictions.

## Subscriptions

Georgia Bass Predictor Pro is planned at $4.99 per month, subject to the price and terms displayed by the relevant app store. Payment, renewal, cancellation, refunds, and billing are handled under the applicable Apple or Google terms. Users can manage or cancel subscriptions through their store account settings.

## Acceptable use

Users may not misuse the service, interfere with its operation, or use it unlawfully.

## Availability and changes

Features, lakes, recommendations, and pricing may change. We do not guarantee uninterrupted availability or specific fishing results.

## Liability and contact

[Have a qualified attorney prepare the applicable warranty disclaimers, liability limits, governing law, and dispute provisions for your business and state.]
