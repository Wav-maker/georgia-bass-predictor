# Georgia Bass Predictor

Cross-platform Expo / React Native starter application for Android and iPhone.

## Included in this project

- Branded mobile app interface
- Free fishing recipe selector for Lake Lanier, Lake Allatoona, and Lake Seminole
- Water clarity and weather inputs
- Strategy, depth, and bait recommendations
- Pro paywall presentation at $4.99/month
- RevenueCat subscription integration hooks (requires your store products and API keys)
- Planned Pro lake expansion list
- Expo cloud build configuration for Android and iOS

## Important status

This is an MVP source codebase, not a published app-store release. It is not a compiled APK/IPA and has not been run through a full device/build test in this environment. It has not been built, signed, tested on physical devices, connected to your RevenueCat account, or approved by Apple/Google. The Pro purchase flow will not work until the configuration steps below are completed.

Lake Seminole's entries are clearly marked as starter patterns. Validate them with local anglers/guides and current conditions before marketing them as expert advice. The Pro lake list is a roadmap; those lakes do not yet have completed recipes.

## 1. Requirements

Install:
- Node.js LTS
- npm
- Expo account
- Android phone or iPhone for testing

## 2. Install and run

From this folder:

```bash
npm install
npx expo start
```

Use Expo Go for an early UI preview where supported. RevenueCat's real native purchase flow requires a development build; Expo Go is only suitable for mocked/preview subscription UI.

## 3. Configure your app identity

Edit `app.json` and replace:

`com.YOURBRAND.georgiabasspredictor`

with a permanent reverse-domain identifier you control, for example:

`com.yourcompany.georgiabasspredictor`

Do not change the identifier after publishing unless you intend to create a separate app listing.

Create your own app icon, splash screen, screenshots, support email, and privacy policy before store submission.

## 4. Configure subscriptions

Recommended provider: RevenueCat.

1. Create a RevenueCat project.
2. Add an iOS app and an Android app using the exact bundle/package identifiers from `app.json`.
3. In App Store Connect, create an auto-renewable subscription product with product ID such as `gbp_pro_monthly` and price $4.99/month (regional pricing may vary).
4. In Google Play Console, create the matching subscription product and base plan at $4.99/month.
5. In RevenueCat, add both store products to an Offering and attach the monthly package.
6. Create an Entitlement named exactly `pro`.
7. Copy the RevenueCat public SDK key for iOS and Android into `app.json` under `extra.revenueCatIosApiKey` and `extra.revenueCatAndroidApiKey`.
8. Build a development client and test purchases using Apple's and Google's sandbox/test accounts.
9. Test purchase, cancellation, expiration, restore, and cross-device behavior before launch.

Never put a RevenueCat secret API key, App Store private key, Google service-account JSON, or payment processor secret in this mobile app. Only the public SDK keys belong in client configuration.

The app expects a RevenueCat entitlement called `pro` and a current Offering with a monthly package. The app's purchase status should be checked carefully before release; also test that the Pro entitlement unlocks every paid feature you add.

## 5. Build for Android and iPhone

Install and sign in:

```bash
npm install
npx eas-cli login
npx eas-cli build:configure
```

Build both platforms:

```bash
npx eas-cli build --platform all --profile production
```

Submit after configuring each store account and completing the app listings:

```bash
npx eas-cli submit --platform android
npx eas-cli submit --platform ios
```

Store submission is not automatic approval. Complete store metadata, age rating, privacy disclosures, screenshots, support URL, subscription disclosures, and review requirements.

## 6. Launch checklist

- [ ] Choose and verify brand/domain name; check trademark conflicts.
- [ ] Replace placeholder app identifiers.
- [ ] Create original app icon and screenshots.
- [ ] Set up a support email and public support website.
- [ ] Publish a privacy policy and terms of use.
- [ ] Decide what analytics are collected and disclose them accurately.
- [ ] Add account deletion if accounts are introduced.
- [ ] Verify fishing recommendations with local experts.
- [ ] Add current water temperature, lake level, wind, and seasonal inputs only after reliable data sources are secured.
- [ ] Complete RevenueCat, Apple, and Google subscription setup.
- [ ] Test on real Android and iPhone devices.
- [ ] Invite beta testers and fix crashes/usability issues.
- [ ] Submit for store review.

## 7. Business notes

$4.99/month is a hypothesis to test, not a proven price. Interview local anglers and measure trial-to-paid conversion, monthly churn, refunds, store fees, customer acquisition cost, and support costs. Do not promise catches or guaranteed fishing outcomes. Avoid claiming real-time data until a reliable data provider is integrated.
