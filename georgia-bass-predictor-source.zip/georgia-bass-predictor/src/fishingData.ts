export type Weather = "Sunny" | "Cloudy";
export type Clarity = "Stained" | "Clear";

export type Recipe = {
  depth: string;
  strategy: string;
  baits: string[];
  note?: string;
};

export type LakeData = {
  isFree: boolean;
  conditions: Record<Clarity, Record<Weather, Recipe>>;
};

export const FREE_LAKES = ["Lake Lanier", "Lake Allatoona", "Lake Seminole"] as const;

// Lake Seminole is intentionally labeled as a starter pattern. Validate and improve
// these suggestions with local guide knowledge, seasonal observations, and user reports
// before marketing them as expert or guaranteed recommendations.
export const LAKES: Record<string, LakeData> = {
  "Lake Lanier": {
    isFree: true,
    conditions: {
      Stained: {
        Sunny: {
          depth: "10–15 feet",
          strategy: "Start on rocky points and clay banks. Check nearby brush and cover, then adjust to baitfish activity.",
          baits: ["Chartreuse crankbait", "Green pumpkin jig with orange trailer", "Colorado-blade spinnerbait"]
        },
        Cloudy: {
          depth: "5–10 feet",
          strategy: "Probe docks, visible brush, and shallow cover. Use a moving bait to locate active fish, then slow down.",
          baits: ["Black and blue chatterbait", "Sexy Shad squarebill crankbait", "Dark trick worm"]
        }
      },
      Clear: {
        Sunny: {
          depth: "20–30 feet",
          strategy: "Look for offshore brush and standing timber with electronics. Use a quiet, finesse presentation.",
          baits: ["Morning Dawn drop shot", "Finesse jig", "Ned rig"]
        },
        Cloudy: {
          depth: "12–18 feet",
          strategy: "Check suspended fish around deep brush. Cover water above structure before slowing down.",
          baits: ["White fluke underspin", "Pro Blue jerkbait", "Spybait"]
        }
      }
    }
  },
  "Lake Allatoona": {
    isFree: true,
    conditions: {
      Stained: {
        Sunny: {
          depth: "4–8 feet",
          strategy: "Target shallow blowdowns, rock, and red-clay points. Make repeated casts to isolated cover.",
          baits: ["Squarebill crankbait", "Texas-rigged creature bait"]
        },
        Cloudy: {
          depth: "2–5 feet",
          strategy: "Fish tight to shallow wood and rock. Use a moving bait to cover water, then pitch a jig to targets.",
          baits: ["Black and blue jig", "Chatterbait"]
        }
      },
      Clear: {
        Sunny: {
          depth: "15–25 feet",
          strategy: "Check deep bluff walls and bridge pilings. Use electronics to identify bait and fish before committing.",
          baits: ["Drop shot", "Ned rig"]
        },
        Cloudy: {
          depth: "8–15 feet",
          strategy: "Look for schooling fish over deeper flats and points. Watch for surface activity.",
          baits: ["Jerkbait", "Topwater walking bait"]
        }
      }
    }
  },
  "Lake Seminole": {
    isFree: true,
    conditions: {
      Stained: {
        Sunny: {
          depth: "3–8 feet (starting range)",
          strategy: "Starter pattern: check submerged grass, hydrilla edges, lily-pad edges, and creek mouths. Look for clean water and baitfish; adjust depth to vegetation and seasonal water levels.",
          baits: ["White or chartreuse spinnerbait", "Texas-rigged creature bait", "Swim jig"],
          note: "Initial Lake Seminole pattern, not a live fishing report. Confirm local conditions before relying on the depth range."
        },
        Cloudy: {
          depth: "2–6 feet (starting range)",
          strategy: "Starter pattern: work grass edges, pads, and shallow cover with moving baits. If the shallow bite is slow, check nearby creek-channel edges.",
          baits: ["White chatterbait", "Black and blue swim jig", "Texas-rigged soft plastic"],
          note: "Initial Lake Seminole pattern, not a live fishing report. Confirm local conditions before relying on the depth range."
        }
      },
      Clear: {
        Sunny: {
          depth: "5–12 feet (starting range)",
          strategy: "Starter pattern: look for vegetation edges, creek-channel bends, and offshore cover. Use electronics where available and fish quietly.",
          baits: ["Green pumpkin Texas rig", "Drop shot", "Swim jig"],
          note: "Initial Lake Seminole pattern, not a live fishing report. Confirm local conditions before relying on the depth range."
        },
        Cloudy: {
          depth: "3–8 feet (starting range)",
          strategy: "Starter pattern: search grass edges and shallow cover with a moving bait, then slow down around isolated targets.",
          baits: ["Spinnerbait", "Chatterbait", "Weightless soft jerkbait"],
          note: "Initial Lake Seminole pattern, not a live fishing report. Confirm local conditions before relying on the depth range."
        }
      }
    }
  }
};

export const PRO_PREVIEW_LAKES = [
  "Lake Oconee",
  "Lake Hartwell",
  "Lake Eufaula",
  "Clarks Hill Lake",
  "West Point Lake",
  "Lake Burton",
  "Carters Lake",
  "High Falls Lake"
];
