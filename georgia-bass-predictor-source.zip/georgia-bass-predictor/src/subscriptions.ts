import { Platform } from "react-native";
import Purchases, { CustomerInfo, PurchasesOffering } from "react-native-purchases";
import Constants from "expo-constants";

const extra = Constants.expoConfig?.extra ?? {};
const ENTITLEMENT_ID = String(extra.revenueCatEntitlement || "pro");

export type SubscriptionState = {
  configured: boolean;
  isPro: boolean;
  offering: PurchasesOffering | null;
  message: string;
};

let configured = false;

export async function configurePurchases(): Promise<boolean> {
  if (Platform.OS === "web") return false;

  const apiKey =
    Platform.OS === "ios"
      ? String(extra.revenueCatIosApiKey || "")
      : String(extra.revenueCatAndroidApiKey || "");

  if (!apiKey) return false;

  try {
    Purchases.configure({ apiKey });
    configured = true;
    return true;
  } catch (error) {
    console.warn("RevenueCat setup failed", error);
    return false;
  }
}

export async function getSubscriptionState(): Promise<SubscriptionState> {
  if (!configured) {
    return {
      configured: false,
      isPro: false,
      offering: null,
      message: "Subscriptions are not connected yet. Add your RevenueCat keys to app.json and create store products before launch."
    };
  }

  try {
    const [info, offerings] = await Promise.all([
      Purchases.getCustomerInfo(),
      Purchases.getOfferings()
    ]);
    return {
      configured: true,
      isPro: Boolean(info.entitlements.active[ENTITLEMENT_ID]),
      offering: offerings.current,
      message: ""
    };
  } catch (error) {
    return {
      configured: true,
      isPro: false,
      offering: null,
      message: "Could not load subscription status. Check your connection and try again."
    };
  }
}

export async function purchasePro(): Promise<CustomerInfo> {
  if (!configured) throw new Error("Subscriptions are not configured yet.");
  const offerings = await Purchases.getOfferings();
  const monthly = offerings.current?.monthly;
  if (!monthly) throw new Error("No monthly Pro product found. Configure the $4.99 monthly package in RevenueCat.");
  const result = await Purchases.purchasePackage(monthly);
  return result.customerInfo;
}

export async function restorePro(): Promise<CustomerInfo> {
  if (!configured) throw new Error("Subscriptions are not configured yet.");
  return Purchases.restorePurchases();
}

export function customerHasPro(info: CustomerInfo): boolean {
  return Boolean(info.entitlements.active[ENTITLEMENT_ID]);
}
