import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator, Alert, SafeAreaView, ScrollView, StatusBar,
  StyleSheet, Text, TouchableOpacity, View
} from "react-native";
import { Picker } from "@react-native-picker/picker";
import { StatusBar as ExpoStatusBar } from "expo-status-bar";
import {
  FREE_LAKES, LAKES, PRO_PREVIEW_LAKES, Clarity, Weather
} from "./src/fishingData";
import {
  configurePurchases, getSubscriptionState, purchasePro, restorePro
} from "./src/subscriptions";

const COLORS = {
  bg: "#0B1F1A", panel: "#14372C", panel2: "#1D4939",
  green: "#8BC69A", pale: "#DCEDE0", muted: "#A8C1B0",
  white: "#FFFFFF", gold: "#E7BD62", border: "#315B49"
};

export default function App() {
  const [lake, setLake] = useState<string>(FREE_LAKES[0]);
  const [clarity, setClarity] = useState<Clarity>("Stained");
  const [weather, setWeather] = useState<Weather>("Cloudy");
  const [isPro, setIsPro] = useState(false);
  const [subscriptionReady, setSubscriptionReady] = useState(false);
  const [subscriptionMessage, setSubscriptionMessage] = useState("");
  const [loadingPurchase, setLoadingPurchase] = useState(false);

  useEffect(() => {
    (async () => {
      await configurePurchases();
      const state = await getSubscriptionState();
      setIsPro(state.isPro);
      setSubscriptionMessage(state.message);
      setSubscriptionReady(true);
    })();
  }, []);

  const recipe = useMemo(() => LAKES[lake]?.conditions[clarity]?.[weather], [lake, clarity, weather]);

  async function buyPro() {
    setLoadingPurchase(true);
    try {
      const info = await purchasePro();
      const active = Boolean(info.entitlements.active.pro);
      setIsPro(active);
      Alert.alert(active ? "Welcome to Pro!" : "Purchase complete", active ? "Your Pro features are unlocked." : "Your purchase was processed. Refresh your subscription status if needed.");
    } catch (e: any) {
      Alert.alert("Pro subscription", e?.message || "Purchase could not be completed.");
    } finally {
      setLoadingPurchase(false);
    }
  }

  async function restore() {
    setLoadingPurchase(true);
    try {
      const info = await restorePro();
      const active = Boolean(info.entitlements.active.pro);
      setIsPro(active);
      Alert.alert(active ? "Purchases restored" : "No active Pro subscription", active ? "Your Pro access is restored." : "No active Pro entitlement was found.");
    } catch (e: any) {
      Alert.alert("Restore purchases", e?.message || "Could not restore purchases.");
    } finally {
      setLoadingPurchase(false);
    }
  }

  function showPro() {
    Alert.alert(
      "Georgia Bass Predictor Pro",
      "Unlock additional lake guides, seasonal patterns, advanced conditions, and saved fishing reports for $4.99/month. Subscription billing must be configured before purchases can go live.",
      [
        { text: "Restore purchases", onPress: restore },
        { text: "Continue", onPress: buyPro },
        { text: "Not now", style: "cancel" }
      ]
    );
  }

  const freeLakes = [...FREE_LAKES];
  return (
    <SafeAreaView style={styles.safe}>
      <ExpoStatusBar style="light" />
      <StatusBar barStyle="light-content" />
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.hero}>
          <Text style={styles.eyebrow}>GEORGIA FISHING INTELLIGENCE</Text>
          <Text style={styles.logo}>GEORGIA BASS{"\n"}PREDICTOR</Text>
          <Text style={styles.tagline}>Find the pattern. Choose the bait. Catch the bass.</Text>
          <View style={styles.heroStats}>
            <View><Text style={styles.statValue}>3</Text><Text style={styles.statLabel}>FREE LAKES</Text></View>
            <View><Text style={styles.statValue}>$4.99</Text><Text style={styles.statLabel}>PRO / MONTH</Text></View>
            <View><Text style={styles.statValue}>GA</Text><Text style={styles.statLabel}>BUILT FOR GEORGIA</Text></View>
          </View>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Build your fishing recipe</Text>
          <Text style={styles.label}>1. SELECT YOUR LAKE</Text>
          <View style={styles.pickerWrap}>
            <Picker selectedValue={lake} onValueChange={(v) => setLake(String(v))} dropdownIconColor={COLORS.green} style={styles.picker}>
              {freeLakes.map((name) => <Picker.Item key={name} label={`${name} · FREE`} value={name} color="#102D25" />)}
            </Picker>
          </View>
          <Text style={styles.label}>2. WATER CLARITY</Text>
          <View style={styles.choiceRow}>
            {(["Stained", "Clear"] as Clarity[]).map((item) => (
              <Choice key={item} label={item} active={clarity === item} onPress={() => setClarity(item)} />
            ))}
          </View>
          <Text style={styles.label}>3. WEATHER</Text>
          <View style={styles.choiceRow}>
            {(["Sunny", "Cloudy"] as Weather[]).map((item) => (
              <Choice key={item} label={item} active={weather === item} onPress={() => setWeather(item)} />
            ))}
          </View>
        </View>

        {recipe && (
          <View style={styles.recipeCard}>
            <View style={styles.recipeHeader}>
              <View><Text style={styles.labelLight}>YOUR FISHING RECIPE</Text><Text style={styles.recipeTitle}>{lake}</Text></View>
              <View style={styles.freePill}><Text style={styles.freePillText}>FREE</Text></View>
            </View>
            <Text style={styles.labelLight}>TARGET DEPTH</Text>
            <Text style={styles.depth}>{recipe.depth}</Text>
            <View style={styles.rule} />
            <Text style={styles.labelLight}>FISHING STRATEGY</Text>
            <Text style={styles.bodyText}>{recipe.strategy}</Text>
            <View style={styles.rule} />
            <Text style={styles.labelLight}>TOP RECOMMENDED BAITS</Text>
            {recipe.baits.map((bait, index) => (
              <View key={bait} style={styles.baitRow}>
                <View style={styles.number}><Text style={styles.numberText}>{index + 1}</Text></View>
                <Text style={styles.baitText}>{bait}</Text>
              </View>
            ))}
            {recipe.note ? <Text style={styles.note}>{recipe.note}</Text> : null}
          </View>
        )}

        <View style={styles.proCard}>
          <Text style={styles.proEyebrow}>UPGRADE YOUR FISHING</Text>
          <Text style={styles.proTitle}>Go Pro. Find more patterns.</Text>
          <Text style={styles.proText}>Unlock additional Georgia lake guides, seasonal pattern libraries, advanced fishing conditions, and saved catch reports.</Text>
          <Text style={styles.proPrice}>$4.99<Text style={styles.proMonth}> / month</Text></Text>
          <TouchableOpacity style={styles.proButton} onPress={showPro} disabled={loadingPurchase}>
            {loadingPurchase ? <ActivityIndicator color={COLORS.bg} /> : <Text style={styles.proButtonText}>UNLOCK PRO</Text>}
          </TouchableOpacity>
          <TouchableOpacity onPress={restore} style={styles.restoreButton}>
            <Text style={styles.restoreText}>Restore purchases</Text>
          </TouchableOpacity>
          {!subscriptionReady ? <Text style={styles.setupText}>Checking subscription status…</Text> :
            (!isPro && subscriptionMessage ? <Text style={styles.setupText}>{subscriptionMessage}</Text> : null)}
          {isPro ? <Text style={styles.proActive}>✓ Pro subscription active</Text> : null}
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Coming to Pro</Text>
          {PRO_PREVIEW_LAKES.map((item) => (
            <View key={item} style={styles.lockedRow}>
              <Text style={styles.lockedName}>{item}</Text>
              <Text style={styles.lockedTag}>PRO</Text>
            </View>
          ))}
          <Text style={styles.noteDark}>These are planned lake expansions, not yet complete fishing guides. Each lake needs verified local patterns before being advertised as available.</Text>
        </View>

        <Text style={styles.disclaimer}>Fishing suggestions are starting points, not guarantees or live reports. Conditions change with season, water level, current, temperature, and fishing pressure. Check local rules, weather, and lake conditions before heading out.</Text>
        <Text style={styles.footer}>GEORGIA BASS PREDICTOR · VERSION 1.0.0</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

function Choice({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.choice, active && styles.choiceActive]}>
      <Text style={[styles.choiceText, active && styles.choiceTextActive]}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  content: { padding: 18, paddingBottom: 42, gap: 16 },
  hero: { paddingTop: 22, paddingBottom: 12 },
  eyebrow: { color: COLORS.green, fontSize: 11, fontWeight: "800", letterSpacing: 2 },
  logo: { color: COLORS.white, fontSize: 35, lineHeight: 39, fontWeight: "900", letterSpacing: 1, marginTop: 12 },
  tagline: { color: COLORS.muted, fontSize: 14, marginTop: 9 },
  heroStats: { flexDirection: "row", justifyContent: "space-between", backgroundColor: COLORS.panel, borderRadius: 16, padding: 14, marginTop: 22 },
  statValue: { color: COLORS.white, fontSize: 19, fontWeight: "900" },
  statLabel: { color: COLORS.muted, fontSize: 8, fontWeight: "800", marginTop: 3 },
  card: { backgroundColor: COLORS.panel, borderRadius: 18, padding: 17, gap: 12 },
  sectionTitle: { color: COLORS.white, fontSize: 20, fontWeight: "900", marginBottom: 2 },
  label: { color: COLORS.green, fontSize: 11, fontWeight: "900", letterSpacing: 1.1, marginTop: 4 },
  pickerWrap: { backgroundColor: "#F4F7F3", borderRadius: 11, overflow: "hidden" },
  picker: { color: "#102D25", height: 52 },
  choiceRow: { flexDirection: "row", gap: 10 },
  choice: { flex: 1, borderWidth: 1, borderColor: COLORS.border, borderRadius: 11, padding: 14, alignItems: "center", backgroundColor: COLORS.bg },
  choiceActive: { backgroundColor: COLORS.green, borderColor: COLORS.green },
  choiceText: { color: COLORS.pale, fontSize: 14, fontWeight: "800" },
  choiceTextActive: { color: COLORS.bg },
  recipeCard: { backgroundColor: COLORS.panel2, borderRadius: 18, padding: 18, gap: 12 },
  recipeHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 4 },
  labelLight: { color: "#B8D9C1", fontSize: 10, fontWeight: "900", letterSpacing: 1.2 },
  recipeTitle: { color: COLORS.white, fontSize: 23, fontWeight: "900", marginTop: 4 },
  freePill: { backgroundColor: "#D8ECDD", borderRadius: 30, paddingHorizontal: 11, paddingVertical: 6 },
  freePillText: { color: "#12372B", fontSize: 10, fontWeight: "900" },
  depth: { color: COLORS.white, fontSize: 31, fontWeight: "900" },
  rule: { height: 1, backgroundColor: "#47705A", marginVertical: 3 },
  bodyText: { color: COLORS.pale, fontSize: 14, lineHeight: 21 },
  baitRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  number: { width: 27, height: 27, borderRadius: 8, backgroundColor: "#47765A", alignItems: "center", justifyContent: "center" },
  numberText: { color: COLORS.white, fontWeight: "900" },
  baitText: { color: COLORS.white, fontSize: 14, fontWeight: "700", flex: 1 },
  note: { color: "#EBD9A8", fontSize: 11, lineHeight: 16, marginTop: 4 },
  proCard: { backgroundColor: "#E7BD62", borderRadius: 18, padding: 18, gap: 10 },
  proEyebrow: { color: "#483510", fontSize: 10, fontWeight: "900", letterSpacing: 1.3 },
  proTitle: { color: "#17251D", fontSize: 22, fontWeight: "900" },
  proText: { color: "#45391F", fontSize: 13, lineHeight: 19 },
  proPrice: { color: "#17251D", fontSize: 31, fontWeight: "900", marginTop: 3 },
  proMonth: { fontSize: 14, fontWeight: "600" },
  proButton: { backgroundColor: "#12372B", padding: 15, borderRadius: 11, alignItems: "center", minHeight: 48, justifyContent: "center" },
  proButtonText: { color: COLORS.white, fontWeight: "900", letterSpacing: 1 },
  restoreButton: { alignItems: "center", padding: 5 },
  restoreText: { color: "#45391F", textDecorationLine: "underline", fontSize: 12, fontWeight: "700" },
  setupText: { color: "#584821", fontSize: 10, lineHeight: 14 },
  proActive: { color: "#12372B", fontSize: 12, fontWeight: "900" },
  lockedRow: { flexDirection: "row", justifyContent: "space-between", borderBottomWidth: 1, borderBottomColor: COLORS.border, paddingVertical: 8 },
  lockedName: { color: COLORS.pale, fontSize: 13, fontWeight: "700" },
  lockedTag: { color: COLORS.gold, fontSize: 10, fontWeight: "900" },
  noteDark: { color: COLORS.muted, fontSize: 11, lineHeight: 16, marginTop: 4 },
  disclaimer: { color: COLORS.muted, fontSize: 10, lineHeight: 15, textAlign: "center", paddingHorizontal: 5 },
  footer: { color: "#678675", fontSize: 9, fontWeight: "800", textAlign: "center", letterSpacing: 1.2, marginTop: 4 }
});
