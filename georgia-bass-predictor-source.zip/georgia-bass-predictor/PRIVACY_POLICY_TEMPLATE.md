# Privacy Policy — Georgia Bass Predictor

**Effective date:** [Insert date]  
**Operator:** [Insert legal business name]  
**Contact:** [Insert support email]  
**Website:** [Insert public website]

This is a draft template only. Have it reviewed and complete every bracketed field before publishing. The final policy must match the app's actual data practices and the disclosures made in Apple App Store Connect and Google Play Console.

## Information we collect

[Describe whether the app collects account details, email addresses, fishing logs, saved locations, device identifiers, crash reports, analytics, or support messages. If the app does not collect a category, say so accurately.]

## Location information

[State whether precise or approximate location is collected, why it is used, whether it is optional, and how users can disable it.]

## Purchases

Subscriptions are processed through Apple App Store or Google Play billing and may be managed with RevenueCat. We do not receive full payment card numbers from the app stores. Explain what subscription status and transaction metadata are processed.

## How information is used

[Describe app operation, saved reports, customer support, security, analytics, and subscription entitlement management.]

## Sharing

[List service providers and purposes, including analytics, crash reporting, hosting, and subscription management. Do not say data is never shared if vendors process it.]

## Retention and deletion

[Explain retention periods and how users can request deletion. If accounts are added, provide an in-app deletion path and a public web deletion path where required.]

## Children's privacy

[State the intended audience and how the service handles information from children. Obtain legal advice before making age-related claims.]

## Security

We use reasonable safeguards appropriate to the information processed. No method of transmission or storage is guaranteed to be completely secure.

## Changes and contact

We may update this policy and will post the current version at [URL]. Contact [email] with privacy questions.
